﻿using NUnit.Framework;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium;

namespace SeleniumTestCases
{
    public class PetStoreAPITest
    {
        private IWebDriver driver;

        [SetUp]
        public void Setup()
        {
            driver = new ChromeDriver();
            driver.Manage().Window.Maximize();
        }

        [TearDown]
        public void TearDown()
        {
            driver.Quit();
        }

        [Test]
        public void TestCreateUserAndVerifyDetails()
        {
            // Navigate to the web application that consumes the API
            driver.Navigate().GoToUrl("https://your-web-application-url");

            // Find the required form fields and fill in the details
            driver.FindElement(By.Id("username")).SendKeys("323243431qw");
            driver.FindElement(By.Id("firstName")).SendKeys("RRRR");
            driver.FindElement(By.Id("lastName")).SendKeys("LLL");
            driver.FindElement(By.Id("email")).SendKeys("we@gmail.com");
            driver.FindElement(By.Id("password")).SendKeys("23dwewe");
            driver.FindElement(By.Id("phone")).SendKeys("2324433");

            // Submit the form to create the user
            driver.FindElement(By.Id("submitBtn")).Click();

            // Assert that the user is created successfully
            Assert.IsTrue(driver.PageSource.Contains("User created successfully"));

            // Navigate to the user's details page
            driver.Navigate().GoToUrl("https://your-web-application-url/user/323243431qw");

            // Assert the retrieved user details
            Assert.IsTrue(driver.PageSource.Contains("Username: 323243431qw"));
            Assert.IsTrue(driver.PageSource.Contains("First Name: RRRR"));
            Assert.IsTrue(driver.PageSource.Contains("Last Name: LLL"));
            Assert.IsTrue(driver.PageSource.Contains("Email: we@gmail.com"));
            Assert.IsTrue(driver.PageSource.Contains("Phone: 2324433"));
        }
    }
}
