﻿using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using TechTalk.SpecFlow;
using NUnit.Framework;

namespace SeleniumTestCases
{
    public class LabCorpJobSearch
    {
        [Binding]
        public class LabCorpJobSearchSteps
        {
            private IWebDriver driver;

            [BeforeScenario]
            public void Setup()
            {
                // Set up the Chrome driver
                driver = new ChromeDriver();
            }

            [AfterScenario]
            public void TearDown()
            {
                // Quit the Chrome driver
                driver.Quit();
            }

            [Given("I open the LabCorp website")]
            public void OpenLabCorpWebsite()
            {
                driver.Navigate().GoToUrl("https://www.labcorp.com");
            }

            [When("I click on the Careers link")]
            public void ClickCareersLink()
            {
                driver.FindElement(By.LinkText("Careers")).Click();
            }

            [When("I search for a position (.*)")]
            public void SearchForPosition(string position)
            {
                driver.FindElement(By.Id("jobTitleId")).SendKeys(position);
                driver.FindElement(By.Id("jobSearch")).Click();
            }

            [When("I select the position from the search results")]
            public void SelectPositionFromSearchResults()
            {
                driver.FindElement(By.CssSelector(".job-title a")).Click();
            }

            [Then("I confirm the job title")]
            public void ConfirmJobTitle()
            {
                string expectedTitle = "QA Test Automation Developer";
                string actualTitle = driver.FindElement(By.CssSelector(".job-title")).Text;
                Assert.AreEqual(expectedTitle, actualTitle);
            }

            [Then("I confirm the job location")]
            public void ConfirmJobLocation()
            {
                string expectedLocation = "Example Location";
                string actualLocation = driver.FindElement(By.CssSelector(".location")).Text;
                Assert.AreEqual(expectedLocation, actualLocation);
            }

            [Then("I confirm the job ID")]
            public void ConfirmJobID()
            {
                string expectedID = "12345";
                string actualID = driver.FindElement(By.CssSelector(".job-id")).Text;
                Assert.AreEqual(expectedID, actualID);
            }

            [Then("I confirm other assertions")]
            public void ConfirmOtherAssertions()
            {
                string expectedDescription = "The right candidate for this role will participate in the test automation technology development and best practice models.";
                string actualDescription = driver.FindElement(By.CssSelector(".job-description p:nth-child(3)")).Text;
                Assert.AreEqual(expectedDescription, actualDescription);

                string expectedManagementSupport = "Prepare test plans, budgets, and schedules.";
                string actualManagementSupport = driver.FindElement(By.CssSelector(".management-support ul li:nth-child(2)")).Text;
                Assert.AreEqual(expectedManagementSupport, actualManagementSupport);

                string expectedExperience = "5+ years of experience in QA automation development and scripting.";
                string actualExperience = driver.FindElement(By.CssSelector(".job-requirements ul li:nth-child(3)")).Text;
                Assert.AreEqual(expectedExperience, actualExperience);

                string expectedAutomationTool = "Selenium";
                string actualAutomationTool = driver.FindElement(By.CssSelector(".job-requirements ul li:nth-child(5)")).Text;
                Assert.IsTrue(actualAutomationTool.Contains(expectedAutomationTool));
            }

            [When("I click on Apply Now")]
            public void ClickApplyNow()
            {
                driver.FindElement(By.CssSelector(".apply-button")).Click();
            }            

            [When("I click on Return to Job Search")]
            public void ClickReturnToJobSearch()
            {
                driver.FindElement(By.CssSelector(".return-to-search")).Click();
            }
        }
    }
}
